package ludo;
import java.sql.*;

public class connect {
    public static void main(String[] args) {
        try {

            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            System.out.println("fail");
        }


        Connection conn = null;

        try {
            conn =
                    DriverManager.getConnection("jdbc:mysql://localhost/ludo",
                            "root", "");


        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }


        Statement stmt = null;
        ResultSet rs = null;

        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM `user`");

            System.out.println("Database: ");

            while (rs.next()) {
                String name = rs.getString("Username");
                String Email = rs.getString("Email");
                //String colour = rs.getString("Colour");
                System.out.println(" Username : " + name);
                System.out.println(" Email : " + Email);
                System.out.println("__________________________________________");
            }


        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }


    }


}
