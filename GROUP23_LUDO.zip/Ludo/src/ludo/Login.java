package ludo;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.Border;
public class Login extends JFrame {



    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel6;
    private JPanel jPanel1;
    private JPasswordField jPasswordField2;
    private JSeparator jSeparator1;
    private JSeparator jSeparator2;
    private JTextField jTextField2;
    private javax.swing.JToggleButton jToggleButton1;

    Connection conn;
    public Login() {
        this.initComponents();
        createConnection();
        this.jTextField2.setBackground(new Color(0, 0, 0, 0));
        this.jPasswordField2.setBackground(new Color(0, 0, 0, 0));
        this.jPanel1.setFocusable(true);
    }

    void createConnection(){
        try {

            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            System.out.println("fail");
        }


        //Connection conn = null;

        try {
            conn =
                    DriverManager.getConnection("jdbc:mysql://localhost/ludo",
                            "root", "");



        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void initComponents() {
        this.jPanel1 = new JPanel() {
            public void paintComponent(Graphics g) {
                ImageIcon im = new ImageIcon("C:\\Users\\user\\Downloads\\Compressed\\LudoGame-master\\Ludo\\src\\ludo\\images\\mainBackground.png");
                Image i = im.getImage();
                g.drawImage(i, 0, 0, this.getSize().width, this.getSize().height, this);
            }
        };
        this.jLabel6 = new JLabel();
        this.jSeparator2 = new JSeparator();
        this.jLabel4 = new JLabel();
        this.jSeparator1 = new JSeparator();
        this.jLabel3 = new JLabel();
        this.jLabel1 = new JLabel();
        this.jToggleButton1 = new JToggleButton();
        this.jButton1 = new JButton();
        this.jTextField2 = new JTextField();
        this.jPasswordField2 = new JPasswordField();
        this.setDefaultCloseOperation(3);
        this.jLabel6.setFont(new Font("Serif", 3, 16));
        this.jLabel6.setForeground(new Color(0, 255, 51));
        this.jLabel6.setHorizontalAlignment(0);
        this.jLabel6.setText("<html>\n<body>\n<u>Don't have an acount? Sign up!</u>\n</body>\n</html>");
        this.jLabel6.setCursor(new Cursor(12));
        this.jLabel6.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                Login.this.jLabel6MouseClicked(evt);
            }
        });
        this.jLabel4.setFont(new Font("Copperplate Gothic Bold", 0, 20));
        this.jLabel4.setForeground(new Color(51, 255, 255));
        this.jLabel4.setText("PASSWORD:");
        this.jLabel3.setFont(new Font("Copperplate Gothic Bold", 0, 20));
        this.jLabel3.setForeground(new Color(51, 255, 255));
        this.jLabel3.setText("USERNAME:");
        this.jLabel1.setFont(new Font("Algerian", 0, 36));
        this.jLabel1.setForeground(new Color(102, 153, 255));
        this.jLabel1.setHorizontalAlignment(0);
        this.jLabel1.setText("<html>\n<body>\n<u>LUDO GAME</u>\n</body>\n</html>");


        jToggleButton1.setBackground(new Color(102, 153, 255));
        jToggleButton1.setFont(new Font("SansSerif", 1, 14));
        jToggleButton1.setForeground(new Color(255, 255, 255));
        jToggleButton1.setText("Login");
        jToggleButton1.setBorder((Border)null);
        jToggleButton1.setCursor(new Cursor(12));
        jToggleButton1.setOpaque(true);
        jToggleButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jTextField2.getText().isEmpty()||String.valueOf(jPasswordField2.getPassword()).isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Cannot be left blank", "Sign Up Error", 2);
                }else
                try {


                    String uname = jTextField2.getText();
                    String pass1 = String.valueOf(jPasswordField2.getPassword());
                    Statement stmt = conn.createStatement();
                    String dbop = "SELECT * FROM `user` WHERE `Username` ='" + uname + "'  AND `Password` = '" + pass1 + "'";
                    ResultSet rs = stmt.executeQuery(dbop);

                    if (rs.next()) {
                        // show a new form
                       MainMenu.main(null);


                    } else {
                        // error message
                        JOptionPane.showMessageDialog(null, "Invalid Username / Password", "Login Error", 2);
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }


            private void dispose() {
            }

        });

        this.jButton1.setBackground(new Color(153, 51, 0));
        this.jButton1.setFont(new Font("MS Reference Sans Serif", 1, 14));
        this.jButton1.setForeground(new Color(255, 255, 255));
        this.jButton1.setText("X");
        this.jButton1.setBorder((Border)null);
        this.jButton1.setCursor(new Cursor(12));
        this.jButton1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                Login.this.jButton1MouseClicked(evt);
            }
        });
        this.jTextField2.setFont(new Font("Serif", 2, 16));
        this.jTextField2.setForeground(new Color(102, 153, 255));
        this.jTextField2.setText("Enter Username");
        this.jTextField2.setBorder((Border)null);
        this.jTextField2.setDisabledTextColor(new Color(0, 102, 102));
        this.jTextField2.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent evt) {
                Login.this.jTextField2FocusGained(evt);
            }

            public void focusLost(FocusEvent evt) {
                Login.this.jTextField2FocusLost(evt);
            }
        });
        this.jPasswordField2.setFont(new Font("Serif", 0, 16));
        this.jPasswordField2.setForeground(new Color(102, 153, 255));
        this.jPasswordField2.setText("jPasswordField2");
        this.jPasswordField2.setBorder((Border)null);
        this.jPasswordField2.setDisabledTextColor(new Color(0, 102, 102));
        this.jPasswordField2.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent evt) {
                Login.this.jPasswordField2FocusGained(evt);
            }

            public void focusLost(FocusEvent evt) {
                Login.this.jPasswordField2FocusLost(evt);
            }
        });
        GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
        this.jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap(284, 32767).addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addComponent(this.jLabel4, -2, 210, -2).addComponent(this.jLabel3, -2, 210, -2).addComponent(this.jLabel1, -2, 280, -2).addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING, false).addComponent(this.jTextField2, Alignment.LEADING, -1, 260, 32767).addComponent(this.jSeparator1, Alignment.LEADING)).addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING, false).addComponent(this.jPasswordField2, Alignment.LEADING, -1, 260, 32767).addComponent(this.jToggleButton1, -2, 100, -2).addComponent(this.jSeparator2, Alignment.LEADING))).addGap(173, 173, 173)).addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent(this.jLabel6, -2, 300, -2).addGap(265, 265, 265)).addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent(this.jButton1, -2, 30, -2).addGap(37, 37, 37)))));
        jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(15, 15, 15).addComponent(this.jButton1, -2, 30, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jLabel1, -2, 60, -2).addGap(44, 44, 44).addComponent(this.jLabel3, -2, 40, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jTextField2, -2, 40, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jSeparator1, -2, 17, -2).addGap(18, 18, 18).addComponent(this.jLabel4, -2, 40, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jPasswordField2, -2, 45, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jSeparator2, -2, 20, -2).addGap(18, 18, 18).addComponent(this.jToggleButton1, -2, 30, -2).addGap(38, 38, 38).addComponent(this.jLabel6, -2, 30, -2).addContainerGap(95, 32767)));
        GroupLayout layout = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel1, -1, -1, 32767).addContainerGap()));
        layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel1, -1, -1, 32767).addContainerGap()));
        this.pack();
    }

    private void jLabel6MouseClicked(MouseEvent evt) {
        MainMenu.main(null);
    }

    private void jButton1MouseClicked(MouseEvent evt) {
        this.setState(1);
        System.exit(0);
    }

    private void jTextField2FocusGained(FocusEvent evt) {
        if (this.jTextField2.getText().equals("Enter Username")) {
            this.jTextField2.setText("");
        }

    }

    private void jPasswordField2FocusGained(FocusEvent evt) {
        if (this.jPasswordField2.getText().equals("jPasswordField2")) {
            this.jPasswordField2.setText("");
        }

    }

    private void jTextField2FocusLost(FocusEvent evt) {
        if (this.jTextField2.getText().equals("")) {
            this.jTextField2.setText("Enter Username");
        }

    }

    private void jPasswordField2FocusLost(FocusEvent evt) {
        if (this.jPasswordField2.getText().equals("")) {
            this.jPasswordField2.setText("jPasswordField2");
        }

    }

    public static void main(String[] args) {
        try {
            LookAndFeelInfo[] var1 = UIManager.getInstalledLookAndFeels();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
                LookAndFeelInfo info = var1[var3];
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException var5) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var5);
        } catch (InstantiationException var6) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var6);
        } catch (IllegalAccessException var7) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var7);
        } catch (UnsupportedLookAndFeelException var8) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, (String)null, var8);
        }

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                (new Login()).setVisible(true);
            }
        });
    }

}
